<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Database Debug Information</h2>";

// Include config
require_once 'config.php';

echo "<h3>Connection Status:</h3>";
if ($conn->connect_error) {
    echo "❌ Connection failed: " . $conn->connect_error;
} else {
    echo "✅ Connected successfully to database: " . DB_NAME;
}

echo "<h3>Checking login_logs table:</h3>";
$result = $conn->query("SHOW TABLES LIKE 'login_logs'");
if ($result && $result->num_rows > 0) {
    echo "✅ login_logs table exists<br>";
    
    // Show table structure
    $columns = $conn->query("DESCRIBE login_logs");
    echo "<h4>Table Structure:</h4>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($col = $columns->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $col['Field'] . "</td>";
        echo "<td>" . $col['Type'] . "</td>";
        echo "<td>" . $col['Null'] . "</td>";
        echo "<td>" . $col['Key'] . "</td>";
        echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . $col['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Show sample data
    $data = $conn->query("SELECT * FROM login_logs ORDER BY waktu_login DESC LIMIT 5");
    echo "<h4>Sample Data (latest 5 records):</h4>";
    if ($data && $data->num_rows > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr>";
        foreach ($data->fetch_assoc() as $key => $value) {
            echo "<th>" . $key . "</th>";
        }
        echo "</tr>";
        $data->data_seek(0);
        while ($row = $data->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . htmlspecialchars($value) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No data in login_logs table";
    }
} else {
    echo "❌ login_logs table does not exist<br>";
    
    // Try to create the table
    echo "<h4>Attempting to create login_logs table:</h4>";
    $sql = "CREATE TABLE IF NOT EXISTS login_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        waktu_login DATETIME NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        fingerprint VARCHAR(255) NOT NULL,
        browser VARCHAR(100) DEFAULT NULL,
        operating_system VARCHAR(100) DEFAULT NULL,
        device_type VARCHAR(50) DEFAULT NULL,
        user_agent TEXT DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if ($conn->query($sql)) {
        echo "✅ Table created successfully<br>";
        
        // Test insert
        $test_sql = "INSERT INTO login_logs (username, waktu_login, ip_address, fingerprint, browser, operating_system, device_type, user_agent) 
                     VALUES ('test_user', NOW(), '127.0.0.1', 'test_fingerprint_123', 'Chrome', 'Windows', 'Desktop', 'Test User Agent')";
        
        if ($conn->query($test_sql)) {
            echo "✅ Test record inserted successfully<br>";
        } else {
            echo "❌ Failed to insert test record: " . $conn->error . "<br>";
        }
    } else {
        echo "❌ Failed to create table: " . $conn->error . "<br>";
    }
}

echo "<h3>Testing functions:</h3>";

// Test detectDeviceInfo function
echo "<h4>Device Detection Test:</h4>";
$device_info = detectDeviceInfo($_SERVER['HTTP_USER_AGENT'] ?? '');
echo "<pre>" . print_r($device_info, true) . "</pre>";

// Test saveLoginLog function
echo "<h4>Login Log Test:</h4>";
if (saveLoginLog('test_user')) {
    echo "✅ Login log saved successfully<br>";
} else {
    echo "❌ Failed to save login log: " . $conn->error . "<br>";
}

echo "<h3>All Tables in Database:</h3>";
$tables = $conn->query("SHOW TABLES");
if ($tables && $tables->num_rows > 0) {
    echo "<ul>";
    while ($table = $tables->fetch_array()) {
        echo "<li>" . $table[0] . "</li>";
    }
    echo "</ul>";
} else {
    echo "No tables found in database";
}

$conn->close();
?>
