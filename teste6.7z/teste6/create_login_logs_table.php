<?php
require_once 'config.php';

// Create login_logs table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS login_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    waktu_login DATETIME NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    fingerprint VARCHAR(255) NOT NULL,
    browser VARCHAR(100) DEFAULT NULL,
    operating_system VARCHAR(100) DEFAULT NULL,
    device_type VARCHAR(50) DEFAULT NULL,
    user_agent TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) {
    echo "✓ login_logs table created successfully\n";
    
    // Test inserting a record
    $test_sql = "INSERT INTO login_logs (username, waktu_login, ip_address, fingerprint, browser, operating_system, device_type, user_agent) 
                 VALUES ('testuser', NOW(), '127.0.0.1', 'test_fingerprint', 'Chrome', 'Windows', 'Desktop', 'Test User Agent')";
    
    if ($conn->query($test_sql)) {
        echo "✓ Test record inserted successfully\n";
        
        // Verify the table structure
        $result = $conn->query("DESCRIBE login_logs");
        echo "Table structure:\n";
        while ($row = $result->fetch_assoc()) {
            echo "- {$row['Field']} ({$row['Type']})\n";
        }
    } else {
        echo "✗ Failed to insert test record: " . $conn->error . "\n";
    }
} else {
    echo "✗ Failed to create table: " . $conn->error . "\n";
}

$conn->close();
?>
