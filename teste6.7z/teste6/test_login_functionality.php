<?php
require_once 'config.php';
require_once 'functions.php';

session_start();

// Test login functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username === 'admin' && $password === 'tuhanmemberkati') {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;

        // Test saveLoginLog function
        echo "<h2>Testing saveLoginLog function...</h2>";
        $result = saveLoginLog($username);

        if ($result) {
            echo "<p style='color: green;'>✓ Login log saved successfully!</p>";
        } else {
            echo "<p style='color: red;'>✗ Failed to save login log!</p>";
        }

        // Check database records
        echo "<h2>Checking database records...</h2>";
        $sql = "SELECT COUNT(*) as total FROM login_logs";
        $result = $conn->query($sql);
        if ($result) {
            $row = $result->fetch_assoc();
            echo "<p>Total records in login_logs table: " . $row['total'] . "</p>";
        }

        // Show latest records
        echo "<h2>Latest login records:</h2>";
        $sql = "SELECT * FROM login_logs ORDER BY waktu_login DESC LIMIT 3";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>ID</th><th>Username</th><th>Waktu Login</th><th>IP Address</th><th>Browser</th><th>OS</th><th>Device</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                echo "<td>" . $row['waktu_login'] . "</td>";
                echo "<td>" . htmlspecialchars($row['ip_address']) . "</td>";
                echo "<td>" . htmlspecialchars($row['browser']) . "</td>";
                echo "<td>" . htmlspecialchars($row['operating_system']) . "</td>";
                echo "<td>" . htmlspecialchars($row['device_type']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No records found in login_logs table.</p>";
        }

        echo "<br><a href='test_login_functionality.php'>Test Again</a>";
        exit;
    } else {
        $error = "Invalid credentials";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Test Login Functionality</title>
</head>
<body>
    <h1>Test Login Functionality</h1>

    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>

    <form method="post">
        <label>Username:</label>
        <input type="text" name="username" value="admin" required><br><br>

        <label>Password:</label>
        <input type="password" name="password" value="tuhanmemberkati" required><br><br>

        <button type="submit">Test Login</button>
    </form>

    <br>
    <a href="index.php">Back to Main</a>
</body>
</html>
