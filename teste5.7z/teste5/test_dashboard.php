<?php
// Test file untuk dashboard
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Starting test...\n";

require_once 'config.php';
echo "Config loaded...\n";

require_once 'functions.php';
echo "Functions loaded...\n";

session_start();
echo "Session started...\n";

// Simulasi login
$_SESSION['logged_in'] = true;
$_SESSION['username'] = 'admin';
echo "Session variables set...\n";

echo "Testing showDashboard function...\n";

// Test fungsi showDashboard
try {
    // Capture output dari showDashboard
    ob_start();
    showDashboard();
    $output = ob_get_clean();
    echo "showDashboard executed successfully...\n";
    echo "Output from showDashboard:\n";
    echo $output;
} catch (Exception $e) {
    echo "Error in showDashboard: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}

echo "Test completed.\n";
?>
