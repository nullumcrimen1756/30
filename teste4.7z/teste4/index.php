<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'includes/url_helper.php';

session_start();

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Set judul halaman default
$page_title = "Dashboard - Sistem Keuangan Gereja";

$action = isset($_GET['action']) ? $_GET['action'] : 'form';

switch ($action) {
    case 'form':
        showForm();
        break;
    case 'submit':
        submitForm();
        break;

    case 'sheet1_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet1Report($jurnal_filter, $tahun_filter);
        include 'views/sheet1_report.php';
        break;
    case 'sheet2_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet2Report($jurnal_filter, $tahun_filter);
        include 'views/sheet2_report.php';
        break;
    case 'sheet3_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet3Report($jurnal_filter, $tahun_filter);
        include 'views/sheet3_report.php';
        break;
    case 'laporan_keuangan':
        $tahun = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');
        $jurnal_filter = isset($_GET['jurnal_filter']) && $_GET['jurnal_filter'] !== '' ? intval($_GET['jurnal_filter']) : null;
        $report_data = generateLaporanKeuangan($tahun, $jurnal_filter);
        $page_title = "Laporan Keuangan Saluran GKPI Medan Kota - Tahun $tahun";
        include 'views/laporan_keuangan.php';
        break;
    case 'get_kategori':
        getKategoriByJurnal();
        break;
    case 'get_subkategori':
        getSubkategori();
        break;
    case 'dashboard':
        showDashboard();
        break;
    default:
        showDashboard();
}

// Include header
include 'views/header.php';

// ... existing content ...

// Include footer
include 'views/footer.php';
?>